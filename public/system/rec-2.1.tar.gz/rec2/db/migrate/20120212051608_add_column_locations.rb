class AddColumnLocations < ActiveRecord::Migration
  def up
    add_column :locations, :valid=>'true', :string
  end

  def down
  end
end
