class ActivityRef < ActiveRecord::Base
	belongs_to :activity
end
