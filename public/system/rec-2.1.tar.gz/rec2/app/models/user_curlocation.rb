class UserCurlocation < ActiveRecord::Base
end
