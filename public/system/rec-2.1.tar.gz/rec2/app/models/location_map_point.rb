class LocationMapPoint < ActiveRecord::Base
  belongs_to :location_map
end
