class ActivityComment < ActiveRecord::Base
  belongs_to :activity
end
