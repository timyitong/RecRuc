class ActivityLivereport < ActiveRecord::Base
  belongs_to :activity
end
