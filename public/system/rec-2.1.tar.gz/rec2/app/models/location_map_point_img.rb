class LocationMapPointImg < ActiveRecord::Base
end
