class ActivityGroup < ActiveRecord::Base
end
