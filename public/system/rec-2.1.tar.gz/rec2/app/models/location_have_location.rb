class LocationHaveLocation < ActiveRecord::Base
  belongs_to :location
end
