class ActivityTweet < ActiveRecord::Base
end
