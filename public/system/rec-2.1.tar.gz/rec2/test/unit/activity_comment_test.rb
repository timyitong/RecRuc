require 'test_helper'

class ActivityCommentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
