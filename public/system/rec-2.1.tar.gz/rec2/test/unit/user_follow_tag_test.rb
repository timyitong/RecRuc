require 'test_helper'

class UserFollowTagTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
