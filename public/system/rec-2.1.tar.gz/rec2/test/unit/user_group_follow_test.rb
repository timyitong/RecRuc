require 'test_helper'

class UserGroupFollowTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
