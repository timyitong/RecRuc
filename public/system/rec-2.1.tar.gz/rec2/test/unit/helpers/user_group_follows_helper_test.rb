require 'test_helper'

class UserGroupFollowsHelperTest < ActionView::TestCase
end
