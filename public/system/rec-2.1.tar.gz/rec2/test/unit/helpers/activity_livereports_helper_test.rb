require 'test_helper'

class ActivityLivereportsHelperTest < ActionView::TestCase
end
