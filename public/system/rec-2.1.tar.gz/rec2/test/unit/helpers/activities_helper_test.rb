require 'test_helper'

class ActivitiesHelperTest < ActionView::TestCase
end
