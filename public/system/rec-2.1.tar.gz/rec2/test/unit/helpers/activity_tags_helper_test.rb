require 'test_helper'

class ActivityTagsHelperTest < ActionView::TestCase
end
