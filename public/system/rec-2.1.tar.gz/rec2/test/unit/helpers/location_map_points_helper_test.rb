require 'test_helper'

class LocationMapPointsHelperTest < ActionView::TestCase
end
