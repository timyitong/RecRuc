require 'test_helper'

class UserFollowLocationsHelperTest < ActionView::TestCase
end
