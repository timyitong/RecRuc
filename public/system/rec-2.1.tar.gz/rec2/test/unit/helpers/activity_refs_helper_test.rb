require 'test_helper'

class ActivityRefsHelperTest < ActionView::TestCase
end
