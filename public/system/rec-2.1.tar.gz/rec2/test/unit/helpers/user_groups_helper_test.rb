require 'test_helper'

class UserGroupsHelperTest < ActionView::TestCase
end
