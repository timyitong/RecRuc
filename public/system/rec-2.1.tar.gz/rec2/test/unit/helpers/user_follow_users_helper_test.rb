require 'test_helper'

class UserFollowUsersHelperTest < ActionView::TestCase
end
