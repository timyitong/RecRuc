require 'test_helper'

class ActivityGroupsHelperTest < ActionView::TestCase
end
