require 'test_helper'

class ActivityUserActionsHelperTest < ActionView::TestCase
end
