require 'test_helper'

class UserFollowTagsHelperTest < ActionView::TestCase
end
