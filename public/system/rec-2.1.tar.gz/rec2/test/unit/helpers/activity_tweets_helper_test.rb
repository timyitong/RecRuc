require 'test_helper'

class ActivityTweetsHelperTest < ActionView::TestCase
end
