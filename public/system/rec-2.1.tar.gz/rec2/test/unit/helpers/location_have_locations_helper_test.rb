require 'test_helper'

class LocationHaveLocationsHelperTest < ActionView::TestCase
end
