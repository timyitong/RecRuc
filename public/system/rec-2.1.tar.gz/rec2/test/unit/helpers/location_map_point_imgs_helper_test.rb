require 'test_helper'

class LocationMapPointImgsHelperTest < ActionView::TestCase
end
