require 'test_helper'

class LocationMapsHelperTest < ActionView::TestCase
end
