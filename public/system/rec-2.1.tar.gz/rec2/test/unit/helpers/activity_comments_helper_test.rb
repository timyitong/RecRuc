require 'test_helper'

class ActivityCommentsHelperTest < ActionView::TestCase
end
