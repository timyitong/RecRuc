require 'test_helper'

class UserCurlocationsHelperTest < ActionView::TestCase
end
