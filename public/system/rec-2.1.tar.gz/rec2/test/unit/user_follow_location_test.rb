require 'test_helper'

class UserFollowLocationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
