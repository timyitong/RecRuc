require 'test_helper'

class LocationMapPointTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
