require 'test_helper'

class LocationHaveLocationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
