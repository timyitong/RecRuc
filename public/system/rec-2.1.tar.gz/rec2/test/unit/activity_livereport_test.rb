require 'test_helper'

class ActivityLivereportTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
