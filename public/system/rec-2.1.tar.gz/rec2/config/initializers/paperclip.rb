Paperclip::Railtie.insert
